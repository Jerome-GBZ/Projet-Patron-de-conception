package ShapePackage.shapes;

public class ShapesEnum {
    public enum Shapes {
        SQUARE,
        TRIANGLE,
        CIRCLE,
        FIGMA,
        COMPOUNDSHAPE
    }
}
